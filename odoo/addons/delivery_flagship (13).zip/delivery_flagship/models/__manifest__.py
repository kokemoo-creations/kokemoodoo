{
    'name': 'FlagShip Carrier Integration',
    'version': '20.0.1.0.0',
    'category': 'Inventory',
    'summary': 'Integrate FlagShip shipping API with Odoo',
    'depends': ['delivery'],
    'data': [
        'security/ir.access.csv',
        'views/delivery_flagship_views.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}