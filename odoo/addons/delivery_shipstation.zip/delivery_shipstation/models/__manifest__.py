{
    'name': 'ShipStation Carrier Integration',
    'version': '20.0.1.0.0',
    'category': 'Inventory',
    'summary': 'Integrate ShipStation shipping API with Odoo',
    'depends': ['delivery'],
    'data': [
        'views/delivery_shipstation_views.xml',
    ],
    'installable': True,
    'application': False,
    'license': 'LGPL-3',
}